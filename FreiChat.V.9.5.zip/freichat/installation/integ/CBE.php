<?php


require 'Joomla.php';

class CBE extends Joomla{}
